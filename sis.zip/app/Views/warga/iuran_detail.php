<?= $this->extend('layouts/admin_template') ?>

<?= $this->section('content') ?>
<section class="content">
    <div class="container-fluid">

        <!-- Detail Iuran -->
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Informasi Iuran</h3>
            </div>
            <div class="card-body">
                <table class="table table-bordered">
                    <tr>
                        <th>Nama Iuran</th>
                        <td><?= esc($iuran['nama_iuran']) ?></td>
                    </tr>
                    <tr>
                        <th>Tahun</th>
                        <td><?= esc($iuran['tahun']) ?></td>
                    </tr>
                    <tr>
                        <th>Jumlah Iuran Per Bulan</th>
                        <td><?= esc($iuran['iuran_bulanan']) ?></td>
                    </tr>
                </table>
            </div>
        </div>

        <!-- Daftar Warga yang Berpartisipasi -->
        <div class="card mt-4">
            <div class="card-header">
                <h3 class="card-title">Daftar Warga dan Status Pembayaran</h3>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>Nama Warga</th>
                                <th>Blok/No</th>
                                <th>Dawis</th>
                                <th>Januari</th>
                                <th>Februari</th>
                                <th>Maret</th>
                                <th>April</th>
                                <th>Mei</th>
                                <th>Juni</th>
                                <th>Juli</th>
                                <th>Agustus</th>
                                <th>September</th>
                                <th>Oktober</th>
                                <th>November</th>
                                <th>Desember</th>
                                <th>Total</th>
                                <th>Keterangan</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($iuranWarga as $warga): ?>
                                <tr>
                                    <td><?= esc($warga['nama_lengkap']) ?></td>
                                    <td><?= esc($warga['blok_no']) ?></td> <!-- Blok/No -->
                                    <td><?= esc($warga['dawis']) ?></td>    <!-- Dawis -->
                                    <td><?= esc($warga['januari']) ?></td>
                                    <td><?= esc($warga['februari']) ?></td>
                                    <td><?= esc($warga['maret']) ?></td>
                                    <td><?= esc($warga['april']) ?></td>
                                    <td><?= esc($warga['mei']) ?></td>
                                    <td><?= esc($warga['juni']) ?></td>
                                    <td><?= esc($warga['juli']) ?></td>
                                    <td><?= esc($warga['agustus']) ?></td>
                                    <td><?= esc($warga['september']) ?></td>
                                    <td><?= esc($warga['oktober']) ?></td>
                                    <td><?= esc($warga['november']) ?></td>
                                    <td><?= esc($warga['desember']) ?></td>
                                    <td><?= esc($warga['total']) ?></td>
                                    <td><?= esc($warga['keterangan']) ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <div class="card-footer">
            <a href="<?= base_url('warga/list') ?>" class="btn btn-secondary">Kembali ke Daftar Iuran</a>
        </div>
    </div>
</section>
<?= $this->endSection() ?>
