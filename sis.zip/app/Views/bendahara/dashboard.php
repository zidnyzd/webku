<?= $this->extend('layouts/admin_template') ?>

<?= $this->section('content') ?>
    <section class="content">
        <div class="container-fluid">
            <div class="row">
            </div>
        </div>
    </section>
<?= $this->endSection() ?>
