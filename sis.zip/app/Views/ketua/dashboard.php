<?= $this->extend('layouts/admin_template') ?>

<?= $this->section('content') ?>

<?= $this->endSection() ?>
